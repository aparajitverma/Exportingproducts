<script setup lang="ts"></script>

<template>
  <section class="section">
    <div class="container grid lg:grid-cols-2 gap-8 items-center">
      <div class="space-y-4">
        <h2>From the Heart of the Himalayas</h2>
        <p class="text-white/80">Experience the journey of authentic Shilajit — from high-altitude rock exudate to a purified, potent extract. Our process preserves fulvic acid and trace minerals for maximum bioavailability.</p>
        <ul class="text-white/80 space-y-2">
          <li>• Sustainable sourcing and responsible partnerships</li>
          <li>• Gentle purification to maintain bioactives</li>
          <li>• Rigorous testing for heavy metals and contaminants</li>
        </ul>
      </div>
      <div class="card overflow-hidden">
        <video class="w-full h-full" controls playsinline preload="metadata" poster="https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1200&auto=format&fit=crop">
          <source src="https://videos.pexels.com/video-files/856994/856994-sd_640_360_25fps.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
    </div>
  </section>
</template>
