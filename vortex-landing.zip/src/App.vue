<script setup lang="ts">
import NavBar from '@/components/NavBar.vue'
import Footer from '@/components/Footer.vue'
import VideoSection from '@/components/VideoSection.vue'
import ContactChat from '@/components/ContactChat.vue'
import variants from '@/data/variants'

function openChat() {
  window.dispatchEvent(new CustomEvent('open-chat'))
}
</script>

<template>
  <div class="min-h-screen bg-hero-gradient">
    <NavBar />

    <!-- Hero -->
    <header class="section">
      <div class="container grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <div class="space-y-6">
          <p class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-white/80">Premium Himalayan • Lab-tested • Authentic</p>
          <h1>
            Himalayan <span class="gold-gradient">Shilajit</span>
          </h1>
          <p class="text-white/80 text-lg leading-relaxed max-w-xl">
            Discover the purest form of Shilajit resin from the high altitudes of the Himalayas. Rich in fulvic acid and trace minerals, crafted to support energy, vitality, and overall wellbeing.
          </p>
          <div class="flex flex-wrap gap-3">
            <button class="btn-primary" @click="openChat">Contact us</button>
            <a href="#variants" class="btn-outline">Explore variants</a>
          </div>
          <ul class="mt-4 grid grid-cols-2 gap-3 text-sm text-white/70 max-w-md">
            <li class="flex items-center gap-2"><span class="i">✅</span> Authentic Himalayan sourcing</li>
            <li class="flex items-center gap-2"><span class="i">✅</span> Third‑party lab tested</li>
            <li class="flex items-center gap-2"><span class="i">✅</span> High fulvic acid content</li>
            <li class="flex items-center gap-2"><span class="i">✅</span> GMP compliant processing</li>
          </ul>
        </div>
        <div class="relative">
          <div class="card p-2">
            <img src="/src/assets/logo.svg" alt="Shilajit" class="hidden" />
            <img class="rounded-2xl w-full h-[420px] object-cover" src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=1600&auto=format&fit=crop" alt="Himalayan mountains" />
          </div>
        </div>
      </div>
    </header>

    <!-- Variants -->
    <section id="variants" class="section">
      <div class="container">
        <div class="mb-10 flex items-end justify-between gap-6">
          <div>
            <h2>Our Shilajit Variants</h2>
            <p class="mt-2 text-white/70 max-w-2xl">Choose from premium resin, convenient capsules, or fine powder — each crafted for purity, potency, and efficacy.</p>
          </div>
        </div>

        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div v-for="v in variants" :key="v.slug" class="card p-6 flex flex-col">
            <div class="mb-4 aspect-[4/3] overflow-hidden rounded-xl border border-white/10">
              <img :src="v.image" :alt="v.name" class="h-full w-full object-cover" />
            </div>
            <h3 class="text-white">{{ v.name }}</h3>
            <p class="mt-2 text-white/70 text-sm">{{ v.description }}</p>
            <ul class="mt-4 space-y-1 text-sm text-white/70">
              <li><span class="text-white">Form:</span> {{ v.form }}</li>
              <li v-if="v.potency"><span class="text-white">Potency:</span> {{ v.potency }}</li>
              <li v-if="v.fulvic"><span class="text-white">Fulvic acid:</span> {{ v.fulvic }}</li>
              <li v-if="v.origin"><span class="text-white">Origin:</span> {{ v.origin }}</li>
            </ul>
            <div class="mt-4 flex flex-wrap gap-2">
              <span v-for="b in v.benefits" :key="b" class="rounded-full bg-white/5 px-3 py-1 text-xs text-white/80 border border-white/10">{{ b }}</span>
            </div>
            <div class="mt-6">
              <a href="#contact" class="btn-primary">Contact us</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Video / Story -->
    <VideoSection />

    <!-- About & Quality -->
    <section id="about" class="section">
      <div class="container grid lg:grid-cols-2 gap-10 items-start">
        <div class="card p-6">
          <h2>What makes our Shilajit different</h2>
          <p class="mt-3 text-white/80">We source from high-altitude rock formations and purify through traditional low‑heat processes to retain bioactive compounds. Each batch undergoes heavy metal screening and microbiological testing.</p>
          <ul class="mt-5 space-y-2 text-white/80">
            <li>• Third‑party lab tested for safety and purity</li>
            <li>• High fulvic acid content and trace minerals</li>
            <li>• GMP compliant facility and standardized processing</li>
          </ul>
        </div>
        <div class="card p-6">
          <h2>How to use</h2>
          <p class="mt-3 text-white/80">Resin: 300–500 mg (a pea-sized portion) once daily, dissolved in warm water, milk, or tea. Capsules/Powder: follow serving size on pack. Cycle 6–8 weeks with short breaks as desired.</p>
          <div class="mt-5 grid grid-cols-2 gap-3 text-sm text-white/70">
            <div class="rounded-xl bg-white/5 p-3 border border-white/10">Morning energy</div>
            <div class="rounded-xl bg-white/5 p-3 border border-white/10">Cognitive support</div>
            <div class="rounded-xl bg-white/5 p-3 border border-white/10">Recovery & vitality</div>
            <div class="rounded-xl bg-white/5 p-3 border border-white/10">Daily wellness</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Contact anchor for CTA focus -->
    <div id="contact" class="section pt-0"></div>

    <Footer />
    <ContactChat />
  </div>
</template>

<style scoped>
.i{display:inline-block;}
</style>
