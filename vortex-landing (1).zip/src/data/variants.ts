export type Variant = {
  slug: string
  name: string
  form: 'Resin' | 'Capsules' | 'Powder' | 'Honey Sticks'
  description: string
  potency?: string
  fulvic?: string
  origin?: string
  benefits: string[]
  image: string
}

const variants: Variant[] = [
  {
    slug: 'pure-resin',
    name: 'Pure Himalayan Shilajit Resin',
    form: 'Resin',
    description:
      'Traditional, full-spectrum resin with rich fulvic acid and trace minerals. Carefully purified at low heat for maximum bioavailability.',
    potency: '300–500 mg per serving',
    fulvic: 'High fulvic acid content',
    origin: 'High-altitude Himalayas',
    benefits: ['Energy & stamina', 'Cognitive support', 'Mineral replenishment'],
    image:
      'https://images.unsplash.com/photo-1615486511388-8a162dc11a7a?q=80&w=1600&auto=format&fit=crop',
  },
  {
    slug: 'capsules',
    name: 'Shilajit Capsules',
    form: 'Capsules',
    description:
      'Convenient encapsulated shilajit for on-the-go routines. Standardized for consistency and purity.',
    potency: '500 mg per capsule',
    fulvic: 'Standardized extract',
    origin: 'Himalayan source material',
    benefits: ['Daily wellness', 'Easy dosing', 'Travel-friendly'],
    image:
      'https://images.unsplash.com/photo-1611077543937-4c0a87f1ea24?q=80&w=1600&auto=format&fit=crop',
  },
  {
    slug: 'powder',
    name: 'Shilajit Powder',
    form: 'Powder',
    description:
      'Fine powder ideal for mixing into smoothies or warm beverages. Balanced profile with broad mineral content.',
    potency: 'As directed (scoop included)',
    fulvic: 'Naturally occurring',
    origin: 'Himalayan rock exudate',
    benefits: ['Mixes easily', 'Versatile use', 'Balanced minerals'],
    image:
      'https://images.unsplash.com/photo-1631661086321-c68aeb7e1916?q=80&w=1600&auto=format&fit=crop',
  },
  {
    slug: 'honey-sticks',
    name: 'Shilajit Honey Sticks',
    form: 'Honey Sticks',
    description: 'Single-serve honey-infused sticks combining pure Shilajit extract with natural Himalayan honey for convenient dosing and pleasant taste. Perfect for travel and daily routines.',
    potency: '200 mg Shilajit per stick',
    fulvic: 'Moderate-high fulvic acid',
    origin: 'Himalayan sourced extract',
    benefits: ['Convenient single-serve', 'Pleasant honey carrier', 'On-the-go energy & focus'],
    image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?q=80&w=1600&auto=format&fit=crop',
  },
]

export default variants
