<script setup lang="ts">
import benefits from '@/data/benefits'
</script>

<template>
  <section class="section bg-transparent">
    <div class="container">
      <div class="mb-8">
        <h2>Benefits of Shilajit</h2>
        <p class="mt-2 text-white/70 max-w-2xl">Key benefits supported by traditional use and modern testing — presented clearly so you can choose the right variant for your needs.</p>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div v-for="b in benefits" :key="b.id" class="card overflow-hidden">
          <div class="relative h-48">
            <img :src="b.image" :alt="b.title" class="absolute inset-0 h-full w-full object-cover" />
            <div class="absolute inset-0 bg-black/30"></div>
            <div class="absolute left-4 bottom-4 right-4">
              <h3 class="text-lg font-semibold text-white">{{ b.title }}</h3>
              <p class="mt-1 text-sm text-white/80">{{ b.description }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
